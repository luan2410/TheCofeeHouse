<<<<<<< HEAD
"# TheCofeeHouse" 
# cach chạy dự án:
# buoc 1 vào be : npm install   
# buoc 2  npm start hoặc node server.js
# buoc 3 vào file index.html -> go live with server .
=======
"# TheCofeeHouse"
#cach chạy dự án:
#buoc 1 vào be : npm install
#buoc 2 npm start hoặc node server.js
#buoc 3 vào file index.html -> go live with server .
>>>>>>> monAn-fix
